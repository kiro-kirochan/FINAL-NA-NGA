-- ============================================================
-- Hospital Management System (HMS) — Database Setup
-- Project: FINAL-BOSS-LEGIT
-- Rebuilt from: kishan0725/Hospital-Management-System
-- Stack: HTML + Bootstrap 5 + PHP + MySQL
-- Author: kiro-kirochan
-- ============================================================

CREATE DATABASE IF NOT EXISTS `hospital`
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `hospital`;

-- ============================================================
-- TABLE 1: doctb (Doctors)
-- Stores doctor records managed in the Doctors module.
-- Primary Key: did (auto-increment integer)
-- ============================================================
DROP TABLE IF EXISTS `doctb`;
CREATE TABLE `doctb` (
    `did`            int(11)      NOT NULL AUTO_INCREMENT,
    `fname`          varchar(50)  NOT NULL,
    `lname`          varchar(50)  NOT NULL,
    `specialization` varchar(100) NOT NULL,
    `contact`        varchar(15)  NOT NULL,
    `email`          varchar(100) DEFAULT NULL,
    PRIMARY KEY (`did`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample doctor records
INSERT INTO `doctb` (`fname`, `lname`, `specialization`, `contact`, `email`) VALUES
('John',    'Smith',   'Cardiology',       '09171000001', 'john.smith@hospital.com'),
('Sarah',   'Jenkins', 'Pediatrics',       '09171000002', 'sarah.jenkins@hospital.com'),
('Michael', 'Chang',   'Dermatology',      '09171000003', 'michael.chang@hospital.com'),
('Emily',   'Watson',  'Neurology',        '09171000004', 'emily.watson@hospital.com'),
('Robert',  'Patel',   'General Medicine', '09171000005', 'robert.patel@hospital.com');

-- ============================================================
-- TABLE 2: patreg (Patients)
-- Stores patient records managed in the Patients module.
-- Primary Key: pid (auto-increment integer)
-- ============================================================
DROP TABLE IF EXISTS `patreg`;
CREATE TABLE `patreg` (
    `pid`     int(11)               NOT NULL AUTO_INCREMENT,
    `fname`   varchar(50)           NOT NULL,
    `lname`   varchar(50)           NOT NULL,
    `age`     int(3)                NOT NULL,
    `gender`  enum('Male','Female') NOT NULL,
    `address` text                  NOT NULL,
    `contact` varchar(15)           NOT NULL,
    `email`   varchar(100)          DEFAULT NULL,
    PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample patient records
INSERT INTO `patreg` (`fname`, `lname`, `age`, `gender`, `address`, `contact`, `email`) VALUES
('Alice', 'Reyes',  22, 'Female', 'Brgy. Poblacion, Calaca, Batangas',  '09171234567', 'alice.reyes@email.com'),
('Ben',   'Torres', 35, 'Male',   'Brgy. Dacanlao, Calaca, Batangas',   '09281234567', 'ben.torres@email.com'),
('Clara', 'Santos', 28, 'Female', 'Brgy. Puting Bato, Calaca, Batangas','09391234567', 'clara.santos@email.com');

-- ============================================================
-- TABLE 3: appointmenttb (Appointments)
-- Links patients and doctors via foreign keys.
-- Primary Key: apid
-- Foreign Keys: pid → patreg(pid), did → doctb(did)
-- ============================================================
DROP TABLE IF EXISTS `appointmenttb`;
CREATE TABLE `appointmenttb` (
    `apid`   int(11) NOT NULL AUTO_INCREMENT,
    `pid`    int(11) NOT NULL,
    `did`    int(11) NOT NULL,
    `apdate` date    NOT NULL,
    `aptime` time    NOT NULL,
    `reason` text    DEFAULT NULL,
    `status` enum('Pending','Confirmed','Completed','Cancelled') NOT NULL DEFAULT 'Pending',
    PRIMARY KEY (`apid`),
    FOREIGN KEY (`pid`) REFERENCES `patreg`(`pid`) ON DELETE CASCADE,
    FOREIGN KEY (`did`) REFERENCES `doctb`(`did`)  ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample appointment records
INSERT INTO `appointmenttb` (`pid`, `did`, `apdate`, `aptime`, `reason`, `status`) VALUES
(1, 1, '2026-06-01', '09:00:00', 'Chest pain and shortness of breath', 'Confirmed'),
(2, 3, '2026-06-02', '10:30:00', 'Skin rash on arms',                  'Pending'),
(3, 2, '2026-06-03', '14:00:00', 'Fever and cough for 3 days',         'Pending');
